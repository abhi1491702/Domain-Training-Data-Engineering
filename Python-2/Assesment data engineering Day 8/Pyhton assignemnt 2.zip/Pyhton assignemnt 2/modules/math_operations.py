# math_operations.py
def square(x):
    return x ** 2
