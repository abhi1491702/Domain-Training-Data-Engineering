# calculator.py
def add(x, y):
    return x + y

if __name__ == "__main__":
    result_calculator = add(3, 4)
    print(f"The sum is: {result_calculator}")
