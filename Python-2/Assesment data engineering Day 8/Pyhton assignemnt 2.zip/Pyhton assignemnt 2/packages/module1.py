# packages/module1.py
from . import module2

def function1():
    print("Function 1 in Module 1")
    module2.function2()
