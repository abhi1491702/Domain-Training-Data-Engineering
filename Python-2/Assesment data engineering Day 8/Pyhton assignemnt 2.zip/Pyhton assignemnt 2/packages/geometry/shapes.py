# packages/geometry/shapes.py
def area_of_circle(radius):
    return 3.14 * radius ** 2
