# packages/module2.py
def function2():
    print("Function 2 in Module 2")
