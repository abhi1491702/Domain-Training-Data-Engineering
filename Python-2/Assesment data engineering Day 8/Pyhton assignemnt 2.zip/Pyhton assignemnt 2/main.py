# main.py
from modules import greetings, math_operations, calculator
from packages.geometry import shapes
from packages import module1
from scripts import read_file, csv_reader, process_lists, usage_of_lambda

# Example 1: Greetings Module
name = "Alice"
greeting_result = greetings.greet(name)
print(greeting_result)

# Example 2: Math Operations Module
number = 7
square_result = math_operations.square(number)
print(f"The square of {number} is: {square_result}")

# Example 3: Calculator Module
sum_result = calculator.add(10, 5)
print(f"The sum is: {sum_result}")

# Example 4: Shapes Module (Package)
radius = 3
area_result = shapes.area_of_circle(radius)
print(f"The area of the circle with radius {radius} is: {area_result}")

# Example 5: Module1 in Package
module1.function1()

# Example 6: Read File Script
read_file_example = read_file.read_file("../data/example.txt")

# Example 7: CSV Reader Script
csv_reader_example = csv_reader.read_csv("../data/example.csv")
print("Data from CSV file:")
for row in csv_reader_example:
    print(row)

# Example 8: Process Lists Script
process_lists_example = process_lists.process_list([1, 2, 3, 4, 5])

# Example 9: Usage of Lambda Script
usage_of_lambda_example = usage_of_lambda.use_lambda(6)

# More examples based on your specific use case...
