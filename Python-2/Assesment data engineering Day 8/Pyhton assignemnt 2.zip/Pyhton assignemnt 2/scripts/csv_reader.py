# scripts/csv_reader.py
import csv

def read_csv(file_path):
    with open(file_path, "r") as file:
        reader = csv.reader(file)
        data_list = [row for row in reader]
    return data_list

csv_data = read_csv("../data/example.csv")
print("Data from CSV file:")
for row in csv_data:
    print(row)
