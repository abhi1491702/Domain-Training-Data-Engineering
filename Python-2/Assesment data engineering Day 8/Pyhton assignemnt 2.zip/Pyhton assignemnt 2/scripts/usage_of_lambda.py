# scripts/usage_of_lambda.py
square_lambda = lambda x: x**2
print("Using Lambda Function:", square_lambda(5))


