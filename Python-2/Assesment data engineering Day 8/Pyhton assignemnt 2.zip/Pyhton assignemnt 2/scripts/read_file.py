# scripts/read_file.py
with open("../data/example.txt", "r") as file:
    content = file.read()
    print(content)
