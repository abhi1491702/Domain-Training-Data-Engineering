
import json
 
# Opening JSON file
f = open('data2.json',)
 
# returns JSON object as
# a dictionary
data2 = json.load(f)
 
# Iterating through the json
# list
for i in data2['emp_details']:
    print(i)
 
# Closing file
f.close()

