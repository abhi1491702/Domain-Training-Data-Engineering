# Simple To-Do List

todo_list = []

while True:
    print("\nTo-Do List Menu:")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        task = input("Enter the task: ")
        todo_list.append(task)
        print(f"Task '{task}' added.")
    elif choice == 2:
        print("To-Do List:", todo_list if todo_list else "Empty")
    elif choice == 3:
        print("Exiting. Goodbye!")
        break
    else:
        print("Invalid choice.")
