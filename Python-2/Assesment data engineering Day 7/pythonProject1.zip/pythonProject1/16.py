# importing sys.path
print(sys.path)