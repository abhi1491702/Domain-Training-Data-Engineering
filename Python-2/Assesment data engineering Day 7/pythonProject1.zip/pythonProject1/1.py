# If statement
num = int(input("Enter a number: "))
if num > 0:
    print(f"{num} is a positive number.")