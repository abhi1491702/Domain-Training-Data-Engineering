# Factorial Calculator

def calculate_factorial(n):
    result = 1
    while n > 1:
        result *= n
        n -= 1
    return result

number = int(input("Enter a number: "))
factorial_result = calculate_factorial(number)
print(f"The factorial of {number} is: {factorial_result}")
