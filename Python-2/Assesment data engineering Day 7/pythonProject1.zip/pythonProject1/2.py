# If-else statement
temperature = float(input("Enter the temperature in Celsius: "))
if temperature > 30:
    print("It's a hot day.")
else:
    print("It's not a hot day.")