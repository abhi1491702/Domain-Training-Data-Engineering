
class Bird:
    # constructor
    def __init__(self, name):
        self.name = name

    def print_info(self):
        print('This bird is:', self.name)

    def fly(self):
        print('The bird can fly')

# Parrot class inherits from Bird class with all attributes.
class Parrot(Bird):
    def __init__(self, name, color, charater):
        # call the constructor of the parent class
        super().__init__(name)
        self.color = color
        self.charater = charater

    # Override method
    def print_info(self):
        print('This bird is:', self.name)
        print('Color of bird is:', self.color)
        print('Character of bird is:', self.charater)

# Creating an instance of Parrot class
obj_parrot = Parrot('parrot', 'red', 'good')

# Accessing methods from both Bird and Parrot classes
obj_parrot.fly()
obj_parrot.print_info()
