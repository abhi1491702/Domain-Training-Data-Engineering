# Mapping function example
numbers = [1, 2, 3, 4, 5]
squared_numbers = map(lambda x: x**2, numbers)
print(list(squared_numbers))


# Python function example
def greet(name):
    print(f"Hello, {name}!")

greet("John")


# Lambda expression example
square = lambda x: x**2
print(square(5))



