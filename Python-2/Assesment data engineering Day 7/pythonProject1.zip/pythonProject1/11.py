# Number functions example
num = -5.67
print(abs(num))
print(round(num))
print(max(2, 7, 1, 9))
print(min(4, 8, 3, 5))