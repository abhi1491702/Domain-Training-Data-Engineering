
# Input and Output
name = input("Enter your name: ")
print("Hello, " + name + "!")



# Introduction to Lists
fruits = ["apple", "banana", "orange"]
print("List of fruits:", fruits)



# List Methods and Slicing
fruits.append("grape")
print("After adding 'grape':", fruits)



print("Sliced list:", fruits[1:3])

# Introduction to Dictionaries & Dictionary Methods
student = {
    "name": "John",
    "age": 20,
    "grade": "A"
}
print("Student details:", student)



# Introduction to Set & Set Methods
numbers = {1, 2, 3, 4, 5}
print("Set of numbers:", numbers)




# Introduction to Map & Map Methods
square = lambda x: x*x
numbers = [1, 2, 3, 4, 5]
squared_numbers = map(square, numbers)
print("Squared numbers:", list(squared_numbers))
