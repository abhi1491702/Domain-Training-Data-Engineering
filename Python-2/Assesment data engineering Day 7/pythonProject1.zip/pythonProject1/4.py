# For Loop
print("Printing numbers from 1 to 5 using a for loop:")
for i in range(1, 6):
    print(i)

# While Loop
count = 0
while count < 3:
    print("This is loop iteration", count + 1)
    count += 1

# Nested Loop
print("Nested Loop Example:")
for i in range(3):
    for j in range(2):
        print(f"({i}, {j})", end=' ')
    print()

    # Break, Continue & Pass
    for char in "Python":
        if char == 'h':
            break
        elif char == 'o':
            continue
        else:
            pass
        print(char)
