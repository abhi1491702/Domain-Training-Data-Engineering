

# If statement
num = int(input("Enter a number: "))
if num > 0:
    print(f"{num} is a positive number.")

# If-else statement
temperature = float(input("Enter the temperature in Celsius: "))
if temperature > 30:
    print("It's a hot day.")
else:
    print("It's not a hot day.")

# If-elif-else statement
grade = int(input("Enter your grade (1-100): "))
if grade >= 90:
    print("A")
elif grade >= 80:
    print("B")
elif grade >= 70:
    print("C")
else:
    print("F")

# For Loop
print("Printing numbers from 1 to 5 using a for loop:")
for i in range(1, 6):
    print(i)

# While Loop
count = 0
while count < 3:
    print("This is loop iteration", count + 1)
    count += 1

# Nested Loop
print("Nested Loop Example:")
for i in range(3):
    for j in range(2):
        print(f"({i}, {j})", end=' ')
    print()

# Break, Continue & Pass
for char in "Python":
    if char == 'h':
        break
    elif char == 'o':
        continue
    else:
        pass
    print(char)

# Input and Output
name = input("Enter your name: ")
print("Hello, " + name + "!")

# Introduction to Lists
fruits = ["apple", "banana", "orange"]
print("List of fruits:", fruits)

# List Methods and Slicing
fruits.append("grape")
print("After adding 'grape':", fruits)

print("Sliced list:", fruits[1:3])

# Introduction to Dictionaries & Dictionary Methods
student = {
    "name": "John",
    "age": 20,
    "grade": "A"
}
print("Student details:", student)

# Introduction to Set & Set Methods
numbers = {1, 2, 3, 4, 5}
print("Set of numbers:", numbers)

# Introduction to Map & Map Methods
square = lambda x: x*x
numbers = [1, 2, 3, 4, 5]
squared_numbers = map(square, numbers)
print("Squared numbers:", list(squared_numbers))
