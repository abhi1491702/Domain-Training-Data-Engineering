
# OOPS example
class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def bark(self):
        print(f"{self.name} says Woof!")

my_dog = Dog("Buddy", 3)
print(my_dog.name)
my_dog.bark()


# Inheritance and Polymorphism example
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        print("Woof!")

class Cat(Animal):
    def speak(self):
        print("Meow!")

def animal_sound(animal):
    animal.speak()

dog = Dog()
cat = Cat()

animal_sound(dog)
animal_sound(cat)



class BankAccount:
    # Constructor
    def __init__(self, account_holder, balance=0):
        self._account_holder = account_holder  # Protected attribute
        self.__balance = balance  # Private attribute

    # Encapsulation - Getter for balance
    def get_balance(self):
        return self.__balance

    # Encapsulation - Setter for balance
    def set_balance(self, new_balance):
        if new_balance >= 0:
            self.__balance = new_balance
        else:
            print("Invalid balance value.")

    # Polymorphism - Display balance
    def display_balance(self):
        print(f"Account balance for {self._account_holder}: ${self.__balance}")

    # Inheritance - Method for transactions
    def perform_transaction(self, amount):
        print("Performing a generic transaction")

    # Method Overriding - Deposit method specific to BankAccount
    def deposit(self, amount):
        self.__balance += amount
        print(f"Deposited ${amount}. New balance: ${self.__balance}")

    # Method Overriding - Withdraw method specific to BankAccount
    def withdraw(self, amount):
        if amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.__balance}")
        else:
            print("Insufficient funds!")

# Inheritance - SavingsAccount inherits from BankAccount
class SavingsAccount(BankAccount):
    def __init__(self, account_holder, balance=0, interest_rate=0.02):
        super().__init__(account_holder, balance)
        self.interest_rate = interest_rate

    # Method Overriding - Deposit method specific to SavingsAccount
    def deposit(self, amount):
        super().deposit(amount)
        self._calculate_interest()
        print(f"Interest calculated. New balance: ${self.get_balance()}")

    # Method Overriding - Withdraw method specific to SavingsAccount
    def withdraw(self, amount):
        super().withdraw(amount)
        self._calculate_interest()
        print(f"Interest calculated. New balance: ${self.get_balance()}")

    # Encapsulation - Private method for calculating interest
    def _calculate_interest(self):
        interest_amount = self.get_balance() * self.interest_rate
        self.set_balance(self.get_balance() + interest_amount)
        print(f"Interest added: ${interest_amount}")

# Creating bank accounts
account1 = BankAccount("Alice", 1000)
account2 = SavingsAccount("Bob", 500, 0.03)

# Performing transactions
account1.display_balance()
account1.deposit(500)
account1.withdraw(200)

account2.display_balance()
account2.deposit(100)
account2.withdraw(300)
