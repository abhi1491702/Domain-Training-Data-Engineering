# Sample string
sentence = "   This is a sample sentence with sample words.   "

# Splitting the sentence into words
words = sentence.split()
print("1. Splitting the sentence into words:", words)

# Joining the words into a sentence
joined_sentence = " ".join(words)
print("2. Joining the words into a sentence:", joined_sentence)

# Replacing occurrences of "sample" with "modified"
modified_sentence = sentence.replace("sample", "modified")
print("3. Replacing 'sample' with 'modified':", modified_sentence)

# Checking if the sentence starts with "This" and ends with "words."
print("4. Does the sentence start with 'This'? :", sentence.startswith("This"))  # True
print("   Does the sentence end with 'words.'? :", sentence.endswith("words."))  # True

# Finding the index of the first occurrence of "sample"
index_of_sample = sentence.find("sample")
print("5. Index of the first occurrence of 'sample':", index_of_sample)

# Counting occurrences of "sample"
sample_count = sentence.count("sample")
print("6. Count of occurrences of 'sample':", sample_count)

# Converting the sentence to uppercase and lowercase
upper_case_sentence = sentence.upper()
lower_case_sentence = sentence.lower()
print("7. Uppercase sentence:", upper_case_sentence)
print("   Lowercase sentence:", lower_case_sentence)

# Stripping leading and trailing whitespaces
stripped_sentence = sentence.strip()
print("8. Stripped sentence:", stripped_sentence)
