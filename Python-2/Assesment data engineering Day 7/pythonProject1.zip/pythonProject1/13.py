
# Default argument values example
def greet(name, greeting="Hello"):
    print(f"{greeting}, {name}!")

greet("Alice")



# Keyword arguments example
def show_info(name, age, city):
    print(f"Name: {name}, Age: {age}, City: {city}")

show_info(age=25, name="Bob", city="New York")


# Special parameters example
def special_params(*args, **kwargs):
    print("Positional arguments:", args)
    print("Keyword arguments:", kwargs)

    special_params(1, 2, 3, name="Alice", age=30)


# Arbitrary argument lists example
def sum_numbers(*nums):
    return sum(nums)

result = sum_numbers(1, 2, 3, 4, 5)
print(result)

