# If-elif-else statement
grade = int(input("Enter your grade (1-100): "))
if grade >= 90:
    print("A")
elif grade >= 80:
    print("B")
elif grade >= 70:
    print("C")
else:
    print("F")
